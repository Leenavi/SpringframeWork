package org.sample.domain;

import lombok.Data;

@Data
public class ImgPathVO {
    private Long imgid;
    private Long productid;
    private String imgPath;
    
}